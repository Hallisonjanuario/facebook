-- Tabela nova (as demais já existem no banco 'facebook')
USE facebook;

CREATE TABLE IF NOT EXISTS comments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    content       VARCHAR(500) NOT NULL,
    comment_date  DATE NOT NULL,
    post_id       INT NOT NULL,
    user_id       INT NOT NULL,
    CONSTRAINT fk_comments_post FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
